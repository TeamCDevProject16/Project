﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Main : Form
    {
        private int childFormNumber = 0;

        public Main()
        {
            InitializeComponent();
        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Do Not Remove
        }

        private void customerInformationToolStripMenuItem_Click(object sender, EventArgs e) //Customer Information Form Select
        {
            Customer frm = new Customer();
            frm.MdiParent = this;
            frm.Show();
        }

        private void orderToolStripMenuItem1_Click(object sender, EventArgs e) //Order Information Form Select
        {
            Order_Information frm = new Order_Information();
            frm.MdiParent = this;
            frm.Show();
        }

        private void paymentInformationToolStripMenuItem_Click(object sender, EventArgs e) //Payment Information Form Select
        {
            Payment frm = new Payment();
            frm.MdiParent = this;
            frm.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e) //System Logout
        {
           // DialogResult dialog = ;
            if (MessageBox.Show("Confirm Logout", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes)
            {
                Login f1 = new Login();
                f1.Show();
                this.Hide();
            }
            //else if (dialog == DialogResult.No)
           // {
                
           // }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) // System Exit
        {
            //DialogResult dialog = MessageBox.Show("Confirm Exit", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (MessageBox.Show("Confirm Logout", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
            //else if (dialog == DialogResult.No)
            //{
                
           // }
        }

        private void inventoryControlToolStripMenuItem_Click(object sender, EventArgs e) //Inventory Control Form Select
        {
            Inventory_Control frm = new Inventory_Control();
            frm.MdiParent = this;
            frm.Show();
        }

        private void orderApprovalToolStripMenuItem_Click(object sender, EventArgs e) //Manager Approval Form Select
        {
            ManagerApproval frm = new ManagerApproval();
            frm.MdiParent = this;
            frm.Show();
        }

        private void orderQualityControlToolStripMenuItem_Click(object sender, EventArgs e) //Order Quality Control Form Select
        {
            QualityControl frm = new QualityControl();
            frm.MdiParent = this;
            frm.Show();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}
