﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //Customer Database Search Button
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e) //Customer ID Input
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e) //Customer First Name Input
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e) //Customer Last Name Input
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e) //Customer Phone Input
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e) //Customer Email Address Input
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e) //Customer Billing Address Input
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e) //Customer Billing City Input
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e) //Customer Billing State Input
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e) //Customer Billing Zip Input
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e) //Customer Shipping Address Input
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e) //Customer Shipping City Input
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e) //Customer Shipping State Input
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e) //Customer Shipping Zip Input
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e) // Same as Billing Address Select
        {

        }
    }
}
